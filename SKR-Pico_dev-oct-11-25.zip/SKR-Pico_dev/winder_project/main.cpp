// =============================================================================
// main.cpp - Winder Application Main
// Purpose: High-level application logic and coordination
// =============================================================================

#include "pico/stdlib.h"
#include "hardware/i2c.h"
#include <cstdio>
#include "pico/multicore.h"

// Include all our modular libraries
#include "config.h"
#include "tmc2209.h"
#include "encoder.h"
#include "stepcompress.h"
#include "move_queue.h"
#include "scheduler.h"
#include "lcd_display.h"
#include "winding_controller.h"

// -----------------------------------------------------------------------------
// Diagnostic LED Controller
// -----------------------------------------------------------------------------
#include "pico/stdlib.h"

// =============================================================================
// Globals 
// =============================================================================
MoveQueue move_queue;
Encoder spindle_encoder;
TMC2209_UART tmc_spindle(uart1, TMC_UART_TX_PIN, TMC_UART_RX_PIN, 0x00); // X axis
TMC2209_UART tmc_traverse(uart1, TMC_UART_TX_PIN, TMC_UART_RX_PIN, 0x02); // Y axis
LCDDisplay lcd(i2c0, 0x27, 20, 4);  // 20x4 LCD at address 0x27
Scheduler scheduler(&move_queue, &spindle_encoder);
WindingController winding_controller(&move_queue, &spindle_encoder, &lcd);
Encoder encoder;

// =============================================================================
// Function Prototypes
// =============================================================================
void init_hardware();
void init_motors();
void setup_winding_parameters();
void core1_entry();
void lcd_display_task(LCDDisplay& lcd, Encoder& encoder);

// =============================================================================
// Main Application
// =============================================================================
int main() {
    stdio_init_all();
    multicore_launch_core1(core1_entry);
    diag_led_init();

    // Boot pattern: LED1+LED2 on = “power-up”
    diag_led_pattern(0b011, 200);
    diag_led_pattern(0b001, 200);
    diag_led_pattern(0b111, 300);

    // Short delay for hardware stabilization
    sleep_ms(100);
    
    // Initialize all hardware
    init_hardware();
    
    // Initialize LCD and show startup message
    lcd.clear();
    lcd.print_at(0, 0, "Wire Winder v1.0");
    lcd.print_at(0, 1, "Initializing...");
    sleep_ms(1000);
    
    // Initialize motor drivers
    lcd.print_at(0, 2, "Motors...");
    init_motors();
    sleep_ms(1000);
    
    // After constructing the Encoder object
    encoder.init();            // <-- REQUIRED: arms A/B/Z IRQs
    encoder.debug_status();    // optional: quick sanity print

    // Start scheduler ISR
    lcd.print_at(0, 3, "Scheduler...");
    if (!scheduler.start(HEARTBEAT_US)) {
        lcd.clear();
        lcd.print_at(0, 0, "ERROR:");
        lcd.print_at(0, 1, "Scheduler failed!");
        while (1) tight_loop_contents();
    }

    //sleep_ms(500);

    sleep_ms(2000);  // Give time to read "Setting Current"
    show_tmc_status();  // This MUST be called!
    
    // Initialize winding controller
    winding_controller.init();
    sleep_ms(500);
    
    // Setup winding parameters
    setup_winding_parameters();
    
    // Show ready message
    lcd.clear();
    lcd.print_at(0, 0, "System Ready");
    lcd.print_at(0, 1, "Auto-starting in 3s");
    sleep_ms(3000);
    
    // Auto-start winding sequence
    if (winding_controller.start()) {
        lcd.clear();
        lcd.print_at(0, 0, "Starting...");
    }
    
    static absolute_time_t hb_time;
    absolute_time_t now = get_absolute_time();
    if (absolute_time_diff_us(now, hb_time) <= 0) {
        gpio_xor_mask(1u << LED2_PIN);   // FAN2 heartbeat from main loop
        hb_time = make_timeout_time_ms(250);
    }

    // Main loop - winding controller, scheduler, and LCD updates
    while (true) {
        // --- motion logic ---
        winding_controller.update();
        scheduler.loop();

        // --- LCD + encoder live display (every 100 ms) ---
        static uint32_t last_lcd_us = 0;
        uint32_t now_us = time_us_32();

        if (now_us - last_lcd_us >= 100000) { // 100 ms
            float dt = (last_lcd_us == 0) ? 0.1f : (now_us - last_lcd_us) / 1e6f;
            last_lcd_us = now_us;

            long pos = encoder.get_position();
            float cps = encoder.get_velocity(dt);     // counts per second
            float rpm = (cps * 60.0f) / ENCODER_CPR;
            float turns = (float)pos / ENCODER_CPR;

            lcd.printf_at(0, 0, "Pos:   %ld    ", pos);
            lcd.printf_at(0, 1, "RPM: %6.1f    ", rpm);
            lcd.printf_at(0, 2, "Turns:%6.2f   ", turns);
        }

        // --- prevent CPU from running flat-out ---
        sleep_ms(10);
    }


    return 0; // Main
}

// =============================================================================
// Core 1 Entry Point - Encoder Polling
// =============================================================================
void core1_entry() {
    // Encoder polling or diagnostics loop
    while (true) {
        sleep_ms(50);
    }
}

// =============================================================================
// Functions
// =============================================================================
static inline void diag_led_init() {
    const uint pins[] = {LED1_PIN, LED2_PIN, LED3_PIN};
    for (int i = 0; i < 3; i++) {
        gpio_init(pins[i]);
        gpio_set_dir(pins[i], GPIO_OUT);
        gpio_put(pins[i], 0);
    }
}

static inline void diag_led_pattern(uint8_t pattern, int delay_ms = 300) {
    // Bit 0→LED1, Bit 1→LED2, Bit 2→LED3
    gpio_put(LED1_PIN, pattern & 0x01);
    gpio_put(LED2_PIN, pattern & 0x02);
    gpio_put(LED3_PIN, pattern & 0x04);
    sleep_ms(delay_ms);
    gpio_put(LED1_PIN, 0);
    gpio_put(LED2_PIN, 0);
    gpio_put(LED3_PIN, 0);
}

static inline void heartbeat_led() {
    static absolute_time_t next = {0};
    absolute_time_t now = get_absolute_time();
    if (absolute_time_diff_us(now, next) <= 0) {
        gpio_xor_mask((1u << LED3_PIN));   // Toggle FAN3 LED
        next = make_timeout_time_ms(SCHED_HEARTBEAT_INTERVAL_MS);
    }
}

static void debug_pulse(int count, int delay_ms = 100) {
    for (int i = 0; i < count; ++i) {
        gpio_put(DEBUG_PIN, 1);     // turn MOSFET ON (LED ON)
        sleep_ms(delay_ms);
        gpio_put(DEBUG_PIN, 0);     // turn MOSFET OFF (LED OFF)
        sleep_ms(delay_ms);
    }
}

void show_tmc_status() {
    uint32_t traverse_status = 0;
    uint32_t spindle_status = 0;
    
    // REMOVE the & and the timeout parameter:
    bool traverse_ok = tmc_traverse.readRegister(TMC_REG_DRV_STATUS, traverse_status);
    bool spindle_ok = tmc_spindle.readRegister(TMC_REG_DRV_STATUS, spindle_status);
    
    lcd.clear();
    lcd.print_at(0, 0, "TMC Status:");
    
    if (!traverse_ok) {
        lcd.print_at(0, 1, "T: COMM FAIL!");
    } else {
        bool t_temp_warn = (traverse_status & (1 << 26)) != 0;
        bool t_temp_shut = (traverse_status & (1 << 27)) != 0;
        
        if (t_temp_shut) {
            lcd.print_at(0, 1, "T: OVERHEAT!!!");
        } else if (t_temp_warn) {
            lcd.print_at(0, 1, "T: Hot Warning");
        } else {
            lcd.print_at(0, 1, "T: OK");
        }
    }
    
    if (!spindle_ok) {
        lcd.print_at(0, 2, "S: COMM FAIL!");
    } else {
        bool s_temp_warn = (spindle_status & (1 << 26)) != 0;
        bool s_temp_shut = (spindle_status & (1 << 27)) != 0;
        
        if (s_temp_shut) {
            lcd.print_at(0, 2, "S: OVERHEAT!!!");
        } else if (s_temp_warn) {
            lcd.print_at(0, 2, "S: Hot Warning");
        } else {
            lcd.print_at(0, 2, "S: OK");
        }
    }
    
    sleep_ms(3000);
}

// =============================================================================
// Hardware Initialization
// =============================================================================
void init_hardware() {
    // Initialize move queue (GPIO pins)
    move_queue.init();
    
    // Initialize encoder
    spindle_encoder.init();
    
    // Initialize I2C bus for LCD
    i2c_init(i2c0, I2C_FREQ_HZ);
    gpio_set_function(I2C_SDA_PIN, GPIO_FUNC_I2C);
    gpio_set_function(I2C_SCL_PIN, GPIO_FUNC_I2C);
    gpio_pull_up(I2C_SDA_PIN);
    gpio_pull_up(I2C_SCL_PIN);
    
    // Initialize LCD
    lcd.init();
    lcd.backlight(true);
}

// =============================================================================
// Motor Driver Initialization
// =============================================================================
void init_motors() {
    stdio_init_all();
    gpio_init(DEBUG_PIN);
    gpio_set_dir(DEBUG_PIN, GPIO_OUT);

    debug_pulse(1);  // Firmware booted
    sleep_ms(100);
    
    lcd.clear();
    lcd.print_at(0, 0, "Setting Current");
    lcd.print_at(0, 1, "Spindle...");

    printf("Testing TMC UART...\n");
    tmc_spindle.testRead();
    tmc_traverse.testRead();

    bool spindle_ok = tmc_spindle.set_rms_current(SPINDLE_CURRENT_MA, R_SENSE);
    
    lcd.print_at(0, 1, spindle_ok ? "Spindle: OK" : "Spindle: FAIL");
    lcd.print_at(0, 2, "Traverse...");
    sleep_ms(500);
    
    bool traverse_ok = tmc_traverse.set_rms_current(TRAVERSE_CURRENT_MA, R_SENSE);
    
    lcd.print_at(0, 2, traverse_ok ? "Traverse: OK" : "Traverse: FAIL");
    lcd.print_at(0, 3, "Microsteps...");
    sleep_ms(500);

    tmc_spindle.set_microsteps(MOTOR_MICROSTEPS);
    tmc_traverse.set_microsteps(MOTOR_MICROSTEPS);
    
    lcd.print_at(0, 3, "Done!");
    sleep_ms(1000);
}

// =============================================================================
// Setup Winding Parameters
// =============================================================================
void setup_winding_parameters() {
    WindingParams params;
    
    // Configure winding job
    params.target_turns = 1000;          // 1000 turns total
    params.spindle_rpm = 300.0f;         // 300 RPM spindle speed
    params.wire_diameter_mm = 0.064f;    // 43 AWG wire (0.064mm)
    params.layer_width_mm = 50.0f;       // 50mm winding width
    params.start_position_mm = 20.0f;    // Start 20mm from home
    params.ramp_time_sec = 3.0f;         // 3 second ramp up/down
    
    // Calculate and set
    params.calculate_layers();
    winding_controller.set_parameters(params);
    
    // Display parameters on LCD
    lcd.clear();
    lcd.print_at(0, 0, "Winding Setup:");
    lcd.printf_at(0, 1, "Turns: %lu", params.target_turns);
    lcd.printf_at(0, 2, "Layers: %lu", params.total_layers);
    lcd.printf_at(0, 3, "RPM: %.0f", params.spindle_rpm);
    sleep_ms(2000);
}
