// =============================================================================
// lcd_display.h - I2C LCD Display Driver (HD44780 compatible)
// Purpose: 4x20 I2C LCD for status display and debugging
// =============================================================================

#pragma once

#include "hardware/i2c.h"
#include <cstdint>
#include <string>

// =============================================================================
// LCD Commands
// =============================================================================
#define LCD_CLEAR_DISPLAY   0x01
#define LCD_RETURN_HOME     0x02
#define LCD_ENTRY_MODE_SET  0x04
#define LCD_DISPLAY_CONTROL 0x08
#define LCD_CURSOR_SHIFT    0x10
#define LCD_FUNCTION_SET    0x20
#define LCD_SET_CGRAM_ADDR  0x40
#define LCD_SET_DDRAM_ADDR  0x80

// Flags for display entry mode
#define LCD_ENTRY_RIGHT          0x00
#define LCD_ENTRY_LEFT           0x02
#define LCD_ENTRY_SHIFT_INCREMENT 0x01
#define LCD_ENTRY_SHIFT_DECREMENT 0x00

// Flags for display on/off control
#define LCD_DISPLAY_ON  0x04
#define LCD_DISPLAY_OFF 0x00
#define LCD_CURSOR_ON   0x02
#define LCD_CURSOR_OFF  0x00
#define LCD_BLINK_ON    0x01
#define LCD_BLINK_OFF   0x00

// Flags for function set
#define LCD_8BIT_MODE 0x10
#define LCD_4BIT_MODE 0x00
#define LCD_2LINE     0x08
#define LCD_1LINE     0x00
#define LCD_5x10_DOTS 0x04
#define LCD_5x8_DOTS  0x00

// Backlight control
#define LCD_BACKLIGHT   0x08
#define LCD_NO_BACKLIGHT 0x00

#define ENABLE_BIT 0x04  // Enable bit

// =============================================================================
// LCDDisplay Class
// =============================================================================
class LCDDisplay {
public:
    /**
     * @brief Constructor
     * @param i2c_inst I2C instance (i2c0 or i2c1)
     * @param addr I2C address (typically 0x27 or 0x3F)
     * @param cols Number of columns (default 20)
     * @param rows Number of rows (default 4)
     */
    LCDDisplay(i2c_inst_t* i2c_inst, uint8_t addr = 0x27, 
               uint8_t cols = 20, uint8_t rows = 4);
    
    bool init();
    void clear();
    void home();
    void set_cursor(uint8_t col, uint8_t row);
    void print(const char* str);
    void print_at(uint8_t col, uint8_t row, const char* str);
    void printf_at(uint8_t col, uint8_t row, const char* format, ...);
    void display(bool on);
    void cursor(bool on);
    void blink(bool on);
    void backlight(bool on);
    void create_char(uint8_t location, const uint8_t charmap[8]);
    void update_display();

private:
    i2c_inst_t* i2c;
    uint8_t i2c_addr;
    uint8_t num_cols;
    uint8_t num_rows;
    uint8_t backlight_val;
    uint8_t display_control;
    uint8_t display_mode;
    
    void send_command(uint8_t cmd);
    void send_data(uint8_t data);
    void write_4bits(uint8_t value);
    void expander_write(uint8_t data);
    void pulse_enable(uint8_t data);
};

// forward declares
class Encoder;
void lcd_display_task(LCDDisplay& lcd, Encoder& encoder);