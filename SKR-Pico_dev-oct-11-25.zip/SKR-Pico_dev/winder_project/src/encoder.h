// =============================================================================
// encoder.h - Quadrature Encoder Decoder
// Purpose: Track rotary encoder position for closed-loop spindle control
// =============================================================================

#pragma once

#include <cstdint>


// =============================================================================
// Encoder Class
// =============================================================================
class Encoder {
public:
    /**
     * @brief Constructor
     */
    Encoder();

    void init();
    void update();
    int32_t get_position() const;
    void set_position(int32_t position);
    void reset();
    float get_revolutions() const;
    bool check_z_pulse();
    float get_velocity(float dt_seconds);
    uint32_t get_isr_hits() const;
    void debug_status() const;
    float get_rpm() const;                  // live RPM (computed from position deltas)

private:
    volatile uint32_t isr_hits = 0;
    volatile int32_t position;
    int32_t last_velocity_position;
    bool last_a;
    bool last_b;
    bool last_z;
    bool z_pulse_detected;
    int32_t  last_vel_pos      = 0;
    uint32_t last_vel_time_us  = 0;
};

extern Encoder encoder;