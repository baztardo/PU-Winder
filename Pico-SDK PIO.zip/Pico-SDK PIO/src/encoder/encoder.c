#include "encoder.h"
#include "encoder.pio.h"
#include "pico/time.h"
#include <stdio.h>

static encoder_t *global_encoder = NULL;

const int8_t encoder_states[16] = {
    0, -1, 1, 0, 1, 0, 0, -1, -1, 0, 0, 1, 0, 1, -1, 0
};

static void encoder_z_handler(uint gpio, uint32_t events) {
    if (global_encoder == NULL) return;
    if (gpio != global_encoder->pin_z) return;
    
    uint64_t current_time = time_us_64();
    if (current_time - global_encoder->last_z_time < 10000) {
        return;
    }
    
    global_encoder->pulses_this_rev = 0;
    
    if (global_encoder->direction_cw) {
        global_encoder->revolution_count++;
    } else {
        global_encoder->revolution_count--;
    }
    
    global_encoder->last_z_time = current_time;
}

bool encoder_init(encoder_t *enc, PIO pio, uint8_t pin_a, uint8_t pin_b, 
                  uint8_t pin_z, int32_t ppr, int32_t cpr) {
    enc->pin_a = pin_a;
    enc->pin_b = pin_b;
    enc->pin_z = pin_z;
    enc->ppr = ppr;
    enc->cpr = cpr;
    enc->pio = pio;
    enc->count = 0;
    enc->revolution_count = 0;
    enc->pulses_this_rev = 0;
    enc->direction_cw = true;
    enc->last_z_time = 0;
    enc->last_count_for_rpm = 0;
    enc->last_rpm_time = time_us_64();
    enc->current_rpm = 0.0f;
    
    gpio_init(pin_a);
    gpio_init(pin_b);
    gpio_set_dir(pin_a, GPIO_IN);
    gpio_set_dir(pin_b, GPIO_IN);
    gpio_pull_up(pin_a);
    gpio_pull_up(pin_b);
    
    uint8_t a_state = gpio_get(pin_a) ? 1 : 0;
    uint8_t b_state = gpio_get(pin_b) ? 1 : 0;
    enc->last_state = (a_state << 1) | b_state;
    
    if (!pio_can_add_program(pio, &quadrature_encoder_program)) {
        printf("ERROR: Cannot add PIO program\n");
        return false;
    }
    
    enc->offset = pio_add_program(pio, &quadrature_encoder_program);
    
    int sm = pio_claim_unused_sm(pio, false);
    if (sm < 0) {
        printf("ERROR: No free PIO state machine\n");
        return false;
    }
    enc->sm = (uint)sm;
    
    quadrature_encoder_program_init(pio, enc->sm, enc->offset, pin_a);
    
    printf("PIO encoder initialized on %s, SM %d\n", 
           pio == pio0 ? "pio0" : "pio1", enc->sm);
    
    gpio_init(pin_z);
    gpio_set_dir(pin_z, GPIO_IN);
    gpio_pull_up(pin_z);
    
    global_encoder = enc;
    
    gpio_set_irq_enabled_with_callback(pin_z, GPIO_IRQ_EDGE_RISE, true, 
                                       &encoder_z_handler);
    
    printf("Encoder initialization complete\n");
    
    return true;
}

void encoder_process(encoder_t *enc) {
    while (!pio_sm_is_rx_fifo_empty(enc->pio, enc->sm)) {
        uint32_t data = pio_sm_get(enc->pio, enc->sm);
        uint8_t current_state = data & 0x03;
        
        if (current_state != enc->last_state) {
            uint8_t index = (enc->last_state << 2) | current_state;
            int8_t change = encoder_states[index];
            
            if (change != 0) {
                enc->count += change;
                enc->pulses_this_rev++;
                
                if (change > 0) {
                    enc->direction_cw = true;
                } else {
                    enc->direction_cw = false;
                }
                
                if (enc->pulses_this_rev >= enc->cpr) {
                    enc->pulses_this_rev = 0;
                }
            }
            
            enc->last_state = current_state;
        }
    }
}

void encoder_reset(encoder_t *enc) {
    enc->count = 0;
    enc->revolution_count = 0;
    enc->pulses_this_rev = 0;
    enc->last_count_for_rpm = 0;
    enc->current_rpm = 0.0f;
}

int32_t encoder_get_count(encoder_t *enc) {
    return enc->count;
}

int32_t encoder_get_revolutions(encoder_t *enc) {
    return enc->revolution_count;
}

int32_t encoder_get_pulses_this_rev(encoder_t *enc) {
    return enc->pulses_this_rev;
}

bool encoder_get_direction(encoder_t *enc) {
    return enc->direction_cw;
}

float encoder_get_rpm(encoder_t *enc) {
    return enc->current_rpm;
}

void encoder_calculate_rpm(encoder_t *enc) {
    uint64_t current_time = time_us_64();
    uint64_t delta_time = current_time - enc->last_rpm_time;
    
    if (delta_time >= 100000) {
        int32_t current_count = enc->count;
        int32_t delta_count = current_count - enc->last_count_for_rpm;
        
        enc->current_rpm = (float)delta_count / enc->cpr * (60000000.0f / delta_time);
        
        enc->last_count_for_rpm = current_count;
        enc->last_rpm_time = current_time;
    }
}